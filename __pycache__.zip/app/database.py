import argparse
import json
import os
import shutil
from collections import Counter

from dotenv import load_dotenv
from langchain_chroma import Chroma
from langchain_community.document_loaders import PyPDFDirectoryLoader
from langchain_core.documents import Document
from langchain_text_splitters import RecursiveCharacterTextSplitter

from .cache import clear_cache
from . import jina_http
from .embeddings import check_index_compatible, get_embedding_function, write_index_config
from .ocr import choose_page_text, unavailable_reason
from .textproc import (
    CHUNK_OVERLAP_SENTENCES,
    CHUNK_SIZE,
    CHUNKING_MODE,
    build_vocab,
    chunk_sentences,
    clean_pdf_text,
    context_header,
    document_summary,
    issuance_title,
    parse_issuance_ids,
    repair_split_words,
    split_sentences,
)

load_dotenv()

CHROMA_PATH = "chroma"
DATA_PATH   = "data"

# Known year/topic folders — must match classifier.KNOWN_YEARS plus "faq".
# This list only affects LOGGING (whether a folder's name is flagged as
# "not filterable by the classifier") — it does not gate which folders get
# loaded. Every folder under DATA_PATH that contains at least one PDF gets
# loaded, no matter its name or depth. Board games are gone: the corpus is
# scoped to BIR tax content only (data/monopoly, data/ticket_to_ride should
# be deleted from disk and the DB re-ingested with --reset).
YEAR_FOLDERS = ["2001", "2002", "2003", "2022", "2023", "2024", "2025", "2026", "faq", "reference"]

# ── Chunking settings ─────────────────────────────────────────────────────
# CHUNKING_MODE=sentence (default): clean the PDF text, repair split words,
#   pack WHOLE sentences into chunks of <= CHUNK_SIZE characters (1-sentence
#   overlap), and tag each chunk with its issuance title, document summary and
#   the issuance numbers it mentions (see app/textproc.py for why).
# CHUNKING_MODE=legacy: the original RecursiveCharacterTextSplitter(800, 80)
#   on raw page text — kept so the thesis can report the before/after as an
#   ablation. Changing the mode (or CHUNK_SIZE / CHUNK_OVERLAP_SENTENCES)
#   changes the index config, so the app asks for `--reset` instead of mixing
#   two kinds of chunks in one index.
# (The values live in app/textproc.py so embeddings.py can record them in
# the index config without importing this module.)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--reset", action="store_true", help="Reset the database.")
    args = parser.parse_args()
    if args.reset:
        print("✨ Clearing Database")
        clear_database()

    documents = load_documents()
    chunks    = split_documents(documents)
    add_to_chroma(chunks)


def _find_pdf_folders(data_path: str) -> list[str]:
    """
    Walk `data_path` recursively and return every directory (including
    data_path itself) that directly contains at least one .pdf file.

    This is the fix for the old "Mode A / Mode B" split in load_documents():
    that logic only ever looked inside the six hardcoded YEAR_FOLDERS *or*
    the flat data/ root, so a PDF sitting in any other subfolder (a new
    year, a re-org, files dropped straight into data/ by /upload while
    year folders also exist) was never picked up by PyPDFDirectoryLoader
    at all — it would sit in ChromaDB's data/ directory on disk forever,
    "uploaded", but invisible to the vector store.
    """
    folders = []
    for root, _dirs, files in os.walk(data_path):
        if any(f.lower().endswith(".pdf") for f in files):
            folders.append(root)
    return sorted(folders)


def load_documents():
    """
    Load every PDF found anywhere under DATA_PATH, tagging each page with a
    `year` metadata value derived from its immediate folder structure
    relative to DATA_PATH:

      data/2003/foo.pdf          -> year="2003"            (unchanged)
      data/monopoly/rules.pdf    -> year="monopoly"         (unchanged)
      data/foo.pdf                -> year="uncategorized"    (was SILENTLY
                                       DROPPED before, whenever any
                                       YEAR_FOLDERS subfolder existed)
      data/2003/amended/foo.pdf  -> year="2003/amended"      (was SILENTLY
                                       DROPPED before — not a listed folder)

    Each folder is loaded with PyPDFDirectoryLoader in its default
    non-recursive mode, one call per folder that directly holds PDFs, so a
    file is never double-loaded and the `source` path PyPDFDirectoryLoader
    stamps into metadata — which calculate_chunk_ids() below uses to build
    the chunk id — stays identical to before for every file living in one
    of the original YEAR_FOLDERS. That means chunks already indexed from
    those folders keep the same ids and are NOT re-added by add_to_chroma's
    existing-id dedup; only genuinely new/previously-missed files add new
    rows.
    """
    all_docs = []

    if not os.path.exists(DATA_PATH):
        print(f"⚠️  Data path '{DATA_PATH}' does not exist — nothing to load.")
        return all_docs

    pdf_folders = _find_pdf_folders(DATA_PATH)
    if not pdf_folders:
        print(f"⚠️  No PDFs found anywhere under '{DATA_PATH}/'.")
        return all_docs

    print(f"📂 Found PDFs in {len(pdf_folders)} folder(s):")
    for f in pdf_folders:
        print(f"   - {f}")

    for folder_path in pdf_folders:
        rel = os.path.relpath(folder_path, DATA_PATH)
        category = "uncategorized" if rel == "." else rel.replace(os.sep, "/")

        print(f"\n  📁 Loading from '{folder_path}/' (category='{category}')...")
        docs = PyPDFDirectoryLoader(folder_path).load()  # non-recursive by default

        if not docs:
            print("     ⚠️  0 page(s) loaded from this folder (unreadable/corrupt PDFs?).")
            continue

        empty_sources = set()
        ocr_new = ocr_replaced = 0
        for doc in docs:
            doc.metadata["year"] = category
            apply_document_metadata(doc, category)
            # Scanned pages: no text layer -> OCR; a poor hidden text layer on
            # a full-page scan -> OCR and keep the cleaner text. Cached on disk
            # by file hash, so --reset doesn't redo the work. See app/ocr.py.
            text, how = choose_page_text(
                doc.metadata.get("source", ""),
                int(doc.metadata.get("page", 0)),
                doc.page_content,
            )
            if how != "layer":
                doc.page_content = text
                doc.metadata["ocr"] = True
                if how == "ocr":
                    ocr_new += 1
                else:
                    ocr_replaced += 1
            if not doc.page_content.strip():
                empty_sources.add(doc.metadata.get("source", "?"))

        print(f"     ✅ {len(docs)} page(s) tagged as year='{category}'")
        if ocr_new:
            print(f"     🔍 {ocr_new} scanned page(s) with no text read via OCR (may contain misread characters)")
        if ocr_replaced:
            print(f"     🔍 {ocr_replaced} scanned page(s) had a poor hidden text layer — replaced with OCR text")
        if empty_sources:
            why = unavailable_reason()
            print(
                f"     🚫 {len(empty_sources)} file(s) still have pages with NO text "
                f"(scanned/blank; they index as nothing until OCR succeeds"
                + (f" — OCR unavailable: {why}" if why else "")
                + "):"
            )
            for src in sorted(empty_sources):
                print(f"         - {src}")

        all_docs.extend(docs)

    print(f"\n📊 Total pages loaded: {len(all_docs)}")
    _print_category_summary(all_docs)
    return all_docs


DOCUMENT_METADATA_PATH = os.path.join("config", "document_metadata.json")
_document_metadata_cache: dict = {}


def _document_metadata() -> dict:
    """config/document_metadata.json, read once ({} if missing or invalid)."""
    if "data" not in _document_metadata_cache:
        data = {}
        try:
            with open(DOCUMENT_METADATA_PATH, encoding="utf-8") as f:
                data = json.load(f)
        except FileNotFoundError:
            pass
        except (OSError, ValueError) as e:
            print(f"⚠️  {DOCUMENT_METADATA_PATH} could not be read, using defaults: {e}")
        _document_metadata_cache["data"] = data
    return _document_metadata_cache["data"]


def apply_document_metadata(doc: Document, category: str) -> None:
    """
    Stamp the knowledge-base metadata that tells document kinds apart:
    document_type (issuance / faq / tax_rule_source), tax_type, tax_year,
    jurisdiction, computation_related, rule_ids. Values come from
    config/document_metadata.json (per-folder defaults, then per-file
    overrides). Every chunk gets every field (Chroma metadata must be scalar,
    so missing values are "" / False), so `where` filters such as
    {"computation_related": True} or {"document_type": "faq"} work uniformly.

    Retrieval does not filter on these yet: they add traceability, and let
    the computation path and future filters find rule documents without
    changing chunk ids.
    """
    cfg = _document_metadata()
    defaults = cfg.get("defaults_by_category") or {}
    fields = {
        "document_type": "issuance", "tax_type": "", "tax_year": "",
        "jurisdiction": "PH", "computation_related": False, "rule_ids": "",
    }
    fields.update(defaults.get("*") or {})
    fields.update(defaults.get(category) or {})
    filename = os.path.basename(str(doc.metadata.get("source", "")).replace("\\", "/"))
    fields.update((cfg.get("files") or {}).get(filename) or {})
    for key, value in fields.items():
        if isinstance(value, (str, bool, int, float)):
            doc.metadata[key] = value


def _print_category_summary(all_docs: list[Document]) -> None:
    counts = Counter(d.metadata.get("year", "unknown") for d in all_docs)
    print("📊 Pages per category:")
    for cat, n in sorted(counts.items()):
        note = ""
        if cat not in YEAR_FOLDERS and cat != "uncategorized":
            note = "  ⚠️  not in YEAR_FOLDERS — classifier's year_filter can never select this category"
        print(f"   {cat}: {n} page(s){note}")


def split_documents(documents: list[Document]):
    if CHUNKING_MODE == "legacy":
        chunks = RecursiveCharacterTextSplitter(
            chunk_size=800,
            chunk_overlap=80,
            length_function=len,
            is_separator_regex=False,
        ).split_documents(documents)
        print(f"✂️  Split into {len(chunks)} chunk(s) (legacy character splitter).")
        return chunks
    return split_documents_by_sentence(documents)


def split_documents_by_sentence(documents: list[Document]) -> list[Document]:
    """
    Sentence-aware chunking (CHUNKING_MODE=sentence):

    1. clean every page (line wraps, broken hyphens — textproc.clean_pdf_text)
       and repair words split by a stray space using the corpus's own
       vocabulary ("shal l" -> "shall");
    2. split each page into sentences and pack whole sentences into chunks of
       <= CHUNK_SIZE characters, so no chunk starts or ends mid-sentence;
    3. stamp metadata used by retrieval:
         title           "RMC No. 116-2024 Digest" (from the filename)
         doc_summary     the issuance's SUBJECT line / first sentence
         context_header  title + summary — embedded and BM25-indexed together
                         with the chunk, but never shown to the generator
         issuance_id     the issuance this chunk belongs to ("RMC-116-2024")
         issuance_ids    every issuance number the chunk is about (its own
                         plus those it cites), comma-joined — Chroma metadata
                         must be scalar

    Pages are chunked one at a time, so the (source, page) -> chunk index
    scheme in calculate_chunk_ids() is unchanged.
    """
    cleaned = [clean_pdf_text(d.page_content) for d in documents]
    vocab = build_vocab(cleaned)
    cleaned = [repair_split_words(t, vocab) for t in cleaned]

    # One summary per source file, from its first page (lowest page number).
    first_pages: dict = {}
    for doc, text in zip(documents, cleaned):
        src = doc.metadata.get("source", "")
        page = int(doc.metadata.get("page", 0) or 0)
        if src not in first_pages or page < first_pages[src][0]:
            first_pages[src] = (page, text)
    summaries = {src: document_summary(text) for src, (_p, text) in first_pages.items()}

    chunks: list[Document] = []
    for doc, text in zip(documents, cleaned):
        if not text.strip():
            continue
        src = doc.metadata.get("source", "")
        title = issuance_title(src)
        own_ids = parse_issuance_ids(title)
        header = context_header(title, summaries.get(src, ""))
        for piece in chunk_sentences(split_sentences(text), CHUNK_SIZE, CHUNK_OVERLAP_SENTENCES):
            ids = own_ids + [i for i in parse_issuance_ids(piece) if i not in own_ids]
            meta = dict(doc.metadata)
            meta.update(
                title=title,
                doc_summary=summaries.get(src, ""),
                context_header=header,
                issuance_id=own_ids[0] if own_ids else "",
                issuance_ids=",".join(ids),
            )
            chunks.append(Document(page_content=piece, metadata=meta))

    print(
        f"✂️  Split into {len(chunks)} sentence-aligned chunk(s) "
        f"(<= {CHUNK_SIZE} chars, {CHUNK_OVERLAP_SENTENCES}-sentence overlap)."
    )
    return chunks


def embedding_text(chunk: Document) -> str:
    """What gets embedded for a chunk: its context header + its text. The
    header lets a question naming an issuance (or its subject) find page 3
    of that issuance, whose own text never repeats the title."""
    header = chunk.metadata.get("context_header") or ""
    return f"{header}\n{chunk.page_content}" if header else chunk.page_content


def add_to_chroma(chunks: list[Document]):
    db = Chroma(
        persist_directory=CHROMA_PATH,
        embedding_function=get_embedding_function()
    )

    chunks_with_ids = calculate_chunk_ids(chunks)
    existing_ids    = set(db.get(include=[])["ids"])
    print(f"📦 Existing documents in DB: {len(existing_ids)}")

    # Refuse to mix vectors made with different embedding settings (e.g. an
    # index built before Jina task adapters were used) — see embeddings.py.
    problem = check_index_compatible(CHROMA_PATH, bool(existing_ids))
    if problem:
        raise RuntimeError(problem)

    new_chunks = [c for c in chunks_with_ids if c.metadata["id"] not in existing_ids]

    if new_chunks:
        print(f"👉 Adding new documents: {len(new_chunks)}")
        # Stamp the config BEFORE adding, so if embedding stops partway (rate
        # limit, network) the partial index is still recognized as compatible
        # and simply re-running `python -m app.database` (WITHOUT --reset)
        # resumes: chunks already stored are skipped by the id check above.
        write_index_config(CHROMA_PATH)
        est = sum(jina_http.estimate_tokens(embedding_text(c)) for c in new_chunks)
        minutes = est / (jina_http.JINA_TPM * jina_http.JINA_SAFETY)
        if minutes > 1:
            print(f"   ≈{est:,} tokens to embed; at the Jina limit of {jina_http.JINA_TPM:,} tokens/min "
                  f"this takes about {minutes:.0f} minute(s). Progress is saved as it goes.")
        if any(c.metadata.get("context_header") for c in new_chunks):
            _add_with_context_headers(db, new_chunks)
        else:
            db.add_documents(new_chunks, ids=[c.metadata["id"] for c in new_chunks])
        write_index_config(CHROMA_PATH)
        # New chunks can change the right answer to a previously cached question.
        clear_cache()
        print("✅ Database updated successfully.")
    else:
        print("✅ No new documents to add.")


def _add_with_context_headers(db: Chroma, chunks: list[Document], batch: int = 256) -> None:
    """
    Store each chunk's CLEAN text as the document (that is what the generator
    and verifier see), but embed header + text (embedding_text()). LangChain's
    add_documents() can only embed the stored text itself, so this writes to
    the underlying Chroma collection directly.
    """
    emb = get_embedding_function()
    for i in range(0, len(chunks), batch):
        part = chunks[i : i + batch]
        vectors = emb.embed_documents([embedding_text(c) for c in part])
        db._collection.upsert(
            ids=[c.metadata["id"] for c in part],
            embeddings=vectors,
            documents=[c.page_content for c in part],
            metadatas=[{k: v for k, v in c.metadata.items() if v is not None} for c in part],
        )  # saved per batch: a later failure keeps everything stored so far
        print(f"   … {min(i + batch, len(chunks))}/{len(chunks)} embedded")


def calculate_chunk_ids(chunks):
    last_page_id        = None
    current_chunk_index = 0

    for chunk in chunks:
        source          = chunk.metadata.get("source")
        page            = chunk.metadata.get("page")
        year            = chunk.metadata.get("year", "unknown")
        current_page_id = f"{source}:{page}"

        if current_page_id == last_page_id:
            current_chunk_index += 1
        else:
            current_chunk_index = 0

        chunk.metadata["id"] = f"{year}:{source}:{page}:{current_chunk_index}"
        last_page_id = current_page_id

    return chunks


def clear_database():
    if os.path.exists(CHROMA_PATH):
        shutil.rmtree(CHROMA_PATH)
        print("🗑️  Database cleared.")
    # Chunk ids survive a rebuild but their text may not (e.g. OCR changes), so
    # cached answers from the old index must not outlive it.
    clear_cache()


if __name__ == "__main__":
    main()